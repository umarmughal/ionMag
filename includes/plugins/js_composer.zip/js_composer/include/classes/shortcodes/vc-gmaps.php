<?php

class WPBakeryShortCode_VC_Gmaps extends WPBakeryShortCode {
}