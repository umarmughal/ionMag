/**
 * Created by ra on 7/11/2016.
 */



var tdcLoader = {
    init: function () {

    }
};


jQuery(window ).load(function(){
    jQuery('body').addClass('tdcComposerLoaded');
});